-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Agu 2024 pada 08.15
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spk`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `Id_Admin` int(11) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Jabatan` varchar(30) NOT NULL,
  `Username` varchar(15) NOT NULL,
  `Password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`Id_Admin`, `Nama`, `Jabatan`, `Username`, `Password`) VALUES
(1, 'Achmad Fauzi', 'Admin', 'admin', '1234'),
(2, 'Dr. Wirawan', 'Kepalasekolah', 'Kepala', '1234');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurusan`
--

CREATE TABLE `jurusan` (
  `Id_Jurusan` int(11) NOT NULL,
  `Nama_Jurusan` varchar(50) NOT NULL,
  `Kuota` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `jurusan`
--

INSERT INTO `jurusan` (`Id_Jurusan`, `Nama_Jurusan`, `Kuota`) VALUES
(1, 'IPS', 100),
(2, 'IPA', 80),
(3, 'Bahasa Arab', 30),
(4, 'Bahasa Japan', 30),
(7, 'Agama', 80);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kriteria`
--

CREATE TABLE `kriteria` (
  `Id_Kriteria` int(11) NOT NULL,
  `Nama_Kriteria` varchar(30) NOT NULL,
  `Bobot` double NOT NULL,
  `Keterangan` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `kriteria`
--

INSERT INTO `kriteria` (`Id_Kriteria`, `Nama_Kriteria`, `Bobot`, `Keterangan`) VALUES
(1, 'Ujian Nasional', 0.3, 'Benefit'),
(2, 'Tes Tertulis', 0.25, 'Benefit'),
(3, 'Tes Wawancara', 0.2, 'Benefit'),
(4, 'Tes Kesehatan', 0.15, 'Benefit'),
(5, 'Raport', 0.1, 'Benefit');

-- --------------------------------------------------------

--
-- Struktur dari tabel `nilai`
--

CREATE TABLE `nilai` (
  `Id_Nilai` int(11) NOT NULL,
  `No_Pendaftaran` varchar(6) NOT NULL,
  `C1` double NOT NULL,
  `C2` int(11) NOT NULL,
  `C3` int(11) NOT NULL,
  `C4` int(11) NOT NULL,
  `C5` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `nilai`
--

INSERT INTO `nilai` (`Id_Nilai`, `No_Pendaftaran`, `C1`, `C2`, `C3`, `C4`, `C5`) VALUES
(1, 'S-0001', 32.5, 87, 75, 80, 60),
(2, 'S-0002', 32.21, 65, 98, 50, 80),
(3, 'S-0003', 33.68, 82, 80, 60, 80),
(4, 'S-0004', 34.25, 85, 90, 60, 75),
(5, 'S-0005', 36.5, 86, 60, 90, 50),
(6, 'S-0006', 34.21, 78, 69, 79, 88),
(7, 'S-0007', 29.2, 85, 60, 60, 75),
(30, 'S-0008', 21.32, 76, 86, 49, 70),
(31, 'S-0009', 23.21, 50, 60, 70, 60),
(32, 'S-0010', 35.3, 76, 82, 83, 86),
(34, 'S-0011', 33.31, 50, 30, 50, 80),
(35, 'S-0012', 28.09, 30, 20, 40, 50),
(36, 'S-0013', 35.09, 80, 95, 100, 83),
(37, 'S-0014', 28.27, 80, 75, 82, 74),
(38, 'S-0015', 32.27, 92, 76, 84, 82),
(39, 'S-0016', 27.09, 76, 80, 80, 63),
(40, 'S-0017', 26.07, 50, 30, 70, 50),
(41, 'S-0018', 34.12, 76, 80, 50, 60),
(42, 'S-0019', 34.23, 52, 83, 86, 75),
(43, 'S-0020', 31.3, 65, 73, 76, 80);

-- --------------------------------------------------------

--
-- Struktur dari tabel `normalisasi`
--

CREATE TABLE `normalisasi` (
  `Id_Normalisasi` int(11) NOT NULL,
  `No_Pendaftaran` varchar(6) NOT NULL,
  `C1` double NOT NULL,
  `C2` double NOT NULL,
  `C3` double NOT NULL,
  `C4` double NOT NULL,
  `C5` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `normalisasi`
--

INSERT INTO `normalisasi` (`Id_Normalisasi`, `No_Pendaftaran`, `C1`, `C2`, `C3`, `C4`, `C5`) VALUES
(1, 'S-0001', 0.890411, 1, 0.789474, 0.8, 0.681818),
(2, 'S-0002', 0.940438, 0.764706, 1, 0.833333, 1),
(3, 'S-0003', 0.983358, 0.964706, 0.816327, 1, 1),
(4, 'S-0004', 1, 1, 0.918367, 1, 0.9375),
(5, 'S-0005', 1, 0.988506, 0.631579, 0.9, 0.568182),
(6, 'S-0006', 0.93726, 0.896552, 0.726316, 0.79, 1),
(7, 'S-0007', 0.8, 0.977011, 0.631579, 0.6, 0.852273),
(30, 'S-0008', 0.622482, 0.894118, 0.877551, 0.816667, 0.875),
(31, 'S-0009', 0.696788, 0.657895, 0.75, 0.875, 0.75),
(32, 'S-0010', 1, 1, 0.987952, 0.965116, 1),
(34, 'S-0011', 1, 0.657895, 0.375, 0.625, 1),
(35, 'S-0012', 0.84329, 0.394737, 0.25, 0.5, 0.625),
(36, 'S-0013', 0.96137, 0.91954, 1, 1, 0.943182),
(37, 'S-0014', 0.828546, 0.869565, 0.9375, 0.97619, 0.902439),
(38, 'S-0015', 0.94578, 1, 0.95, 1, 1),
(39, 'S-0016', 0.813269, 1, 1, 1, 0.7875),
(40, 'S-0017', 0.782648, 0.657895, 0.375, 0.875, 0.625),
(41, 'S-0018', 1, 0.826087, 1, 0.595238, 0.731707),
(42, 'S-0019', 0.969688, 0.684211, 1, 1, 0.872093),
(43, 'S-0020', 0.886686, 0.855263, 0.879518, 0.883721, 0.930233);

-- --------------------------------------------------------

--
-- Struktur dari tabel `peserta`
--

CREATE TABLE `peserta` (
  `No_Pendaftaran` varchar(6) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `Password` varchar(15) NOT NULL,
  `NISN` varchar(20) NOT NULL,
  `Id_Jurusan` int(11) NOT NULL,
  `Nama` varchar(50) NOT NULL,
  `Jenis_Kelamin` varchar(1) NOT NULL,
  `Tanggal_Lahir` date NOT NULL,
  `Alamat` varchar(50) DEFAULT NULL,
  `Asal_Sekolah` varchar(30) DEFAULT NULL,
  `Nilai_UN` double NOT NULL,
  `Nilai_Akhir` double DEFAULT NULL,
  `Ranking` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `peserta`
--

INSERT INTO `peserta` (`No_Pendaftaran`, `Email`, `Password`, `NISN`, `Id_Jurusan`, `Nama`, `Jenis_Kelamin`, `Tanggal_Lahir`, `Alamat`, `Asal_Sekolah`, `Nilai_UN`, `Nilai_Akhir`, `Ranking`) VALUES
('S-0001', 'rizalbayu@gmail.com', '1234', '2109721212', 1, 'Rizal Bayu', 'L', '2007-06-20', 'Jalan Kebon baru Tebet Raya', 'SMP 234', 32.5, 0.8632, NULL),
('S-0002', 'Syifaaul12@gmail.com', '1234', '0090895317', 2, 'Syifa Aulia Putri', 'P', '2010-10-11', 'Jl. RTM kelapa dua cimanggis kota depok', 'MTS N 18', 32.21, 0.898308, 2),
('S-0003', 'Mahe17@gmail.com', '1234', '7821312621', 2, 'Dede Agus Mahendra', 'L', '2008-01-17', 'Jl. hj subur no 18 Lenteng Agung jakarta selatan', 'MTS N 4', 33.68, 0.949449, NULL),
('S-0004', 'agung21@gmail.com', '1234', '0837897621', 2, 'Reza Agung', 'L', '2011-12-22', 'Jl. Areman no 19 kelapa dua cimanggis kota depok', 'SMP Raflesia', 34.25, 0.977423, NULL),
('S-0005', 'Kamal@gmail.com', '1234', '0830697621', 1, 'Kamal Ardi', 'L', '2018-12-07', 'Komp Cijantung palsigunung selatan', 'MTS 1', 36.5, 0.865261, NULL),
('S-0006', 'utaadit07@gmil.com', '1234', '0130654315', 1, 'Putra Rahmawan Aditya', 'L', '2009-12-07', 'Jl. Mohkahfi no 23 Ciganjur jakarta selatan', 'MTS Assalam', 34.21, 0.869079, NULL),
('S-0007', 'Sandy1609@gmail.com', '1234', '0730684311', 1, 'Muhammad Sandy', 'L', '2009-05-16', 'Jl. Hj Shibi Lenteng agung no 09', 'SMP 276', 29.2, 0.785796, NULL),
('S-0008', 'Puput01@gmail.com', '1234', '0782141267', 2, 'Tia Agustina Putri', 'P', '2009-10-12', 'gg. Hj Saman no 23 Lenteng Agung', 'SMP 62', 21.32, 0.795784, NULL),
('S-0009', 'fiq13@dsa.com', '1234', '0312141221', 7, 'Muhamad Al Fiqri Putra', 'L', '2009-11-23', 'Jl. Setu Katulampa no 3 Jakarta Timur', 'Pesantren Al Maidah', 23.21, 0.72976, NULL),
('S-0010', 'Anisamaul2@gmail.com', '1234', '0020997109', 3, 'Anisa Maulida Rahma', 'P', '2002-06-02', 'Jl. Serengseng Sawah No 13 Len', 'MTS N 4', 35.3, 0.992358, NULL),
('S-0011', 'Bilaa04@gmail.com', '1234', '20183456', 7, 'Nabila Mutiah Farras', 'P', '2010-04-07', 'Jl. Tanjung Barat No 92 Jakarta Selatan', 'SMP 39', 33.31, 0.733224, NULL),
('S-0012', 'leh26@gmail.com', '1234', '0262141125', 7, 'Solehudin nugraha', 'L', '2009-05-11', 'Jl Raya lenteng agung 09 jakarta selatan', 'SMP Kartika Wijaya', 28.09, 0.539171, NULL),
('S-0013', 'Naz14@gmail.com', '1234', '20724567', 1, 'Nazihah Zaidah', 'P', '2009-03-16', 'Tebet Raya 02 Jakarta Selatan', 'SMP 62', 35.09, 0.962614, NULL),
('S-0014', 'fadlan23@gmail.com', '1234', '0236213619', 4, 'Muhamad Fadlan', 'L', '2009-02-23', 'jl. Ps Minggu no 02 Jakarta Selatan', 'SMP 21', 28.27, 0.890127, NULL),
('S-0015', 'durman07@gmail.com', '1234', '0702621361', 4, 'Abdurahman Masedur', 'L', '2009-03-07', 'Jl. Bakhti yudha Cijantung no 12 Jakarta Timur', 'MTS N 18', 32.27, 0.973734, NULL),
('S-0016', 'Rikas08@gmail.com', '1234', '0821621345', 7, 'Rika Sastika', 'P', '2008-09-08', 'Jl. Hj mahendra no 13 Lenteng agung Jakarta selata', 'SMP Kartika Wijaya', 27.09, 0.922731, NULL),
('S-0017', 'izal12@gmail.com', '1234', '1210621346', 7, 'Faizal Al-Mukorobin', 'L', '2008-10-12', 'Jl. RTM  no 12 kelapa dua cimanggis kota depok', 'MTS N 18', 26.07, 0.668018, NULL),
('S-0018', 'tang87@gmail.com', '1234', '1510626341', 4, 'Bintang Indah Cahyani', 'P', '2008-05-19', 'Jalan raya ragunan indah permai no 12 Jakarta Sela', 'SMP 234', 34.12, 0.868978, NULL),
('S-0019', 'dimuy@gmail.com', '1234', '0510627342', 3, 'Aldi Muhammad Yusuf', 'L', '2009-06-05', 'Kelapa dua depok Cimanggis tugu', 'MTS 20 Mei', 34.23, 0.899168, NULL),
('S-0020', 'xan21@gmail.com', '1234', '0910647362', 3, 'Muhamad Fauzan ', 'L', '2009-01-12', 'Jl. Setu Gentung Katulampa no 3 Kota depok', 'MTS N 4', 31.3, 0.881307, NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Id_Admin`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Indeks untuk tabel `jurusan`
--
ALTER TABLE `jurusan`
  ADD PRIMARY KEY (`Id_Jurusan`),
  ADD UNIQUE KEY `Nama_Jurusan` (`Nama_Jurusan`);

--
-- Indeks untuk tabel `kriteria`
--
ALTER TABLE `kriteria`
  ADD PRIMARY KEY (`Id_Kriteria`);

--
-- Indeks untuk tabel `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`Id_Nilai`),
  ADD UNIQUE KEY `No_Pendaftaran` (`No_Pendaftaran`) USING BTREE;

--
-- Indeks untuk tabel `normalisasi`
--
ALTER TABLE `normalisasi`
  ADD PRIMARY KEY (`Id_Normalisasi`),
  ADD KEY `No_Pendaftaran` (`No_Pendaftaran`);

--
-- Indeks untuk tabel `peserta`
--
ALTER TABLE `peserta`
  ADD PRIMARY KEY (`No_Pendaftaran`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD UNIQUE KEY `NISN` (`NISN`),
  ADD KEY `Id_Jurusan` (`Id_Jurusan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `Id_Admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `jurusan`
--
ALTER TABLE `jurusan`
  MODIFY `Id_Jurusan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `kriteria`
--
ALTER TABLE `kriteria`
  MODIFY `Id_Kriteria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `nilai`
--
ALTER TABLE `nilai`
  MODIFY `Id_Nilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT untuk tabel `normalisasi`
--
ALTER TABLE `normalisasi`
  MODIFY `Id_Normalisasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `nilai`
--
ALTER TABLE `nilai`
  ADD CONSTRAINT `nilai_ibfk_1` FOREIGN KEY (`No_Pendaftaran`) REFERENCES `peserta` (`No_Pendaftaran`);

--
-- Ketidakleluasaan untuk tabel `normalisasi`
--
ALTER TABLE `normalisasi`
  ADD CONSTRAINT `normalisasi_ibfk_1` FOREIGN KEY (`No_Pendaftaran`) REFERENCES `peserta` (`No_Pendaftaran`);

--
-- Ketidakleluasaan untuk tabel `peserta`
--
ALTER TABLE `peserta`
  ADD CONSTRAINT `peserta_ibfk_1` FOREIGN KEY (`Id_Jurusan`) REFERENCES `jurusan` (`Id_Jurusan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
