    </div>
    <footer class="app-footer">
      <div>
        <span>Copyright &copy;</span>
        <a href="https://www.man13-jkt.sch.id/">man13-jkt.sch.id.</a>
        <span>All rights reserved | PMH.</span>
      </div>
      <div class="ml-auto">
        <span>Powered by</span>
        <a href="https://www.man13-jkt.sch.id/">man13-jkt.sch.id.</a>
      </div>
    </footer>
    <!-- CoreUI and necessary plugins-->
    <script src="../asset/vendors/jquery/js/jquery.min.js"></script>
    <script src="../asset/vendors/popper.js/js/popper.min.js"></script>
    <script src="../asset/vendors/bootstrap/js/bootstrap.min.js"></script>
    <script src="../asset/vendors/pace-progress/js/pace.min.js"></script>
    <script src="../asset/vendors/perfect-scrollbar/js/perfect-scrollbar.min.js"></script>
    <script src="../asset/vendors/@coreui/coreui/js/coreui.min.js"></script>
    <!-- Plugins and scripts required by this view-->
    <script src="../asset/vendors/chart.js/js/Chart.min.js"></script>
    <script src="../asset/vendors/@coreui/coreui-plugin-chartjs-custom-tooltips/js/custom-tooltips.min.js"></script>
    <script src="../asset/js/main.js"></script>
  </body>
</html>