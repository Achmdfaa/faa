<?php 
session_start();
  include "../lib/koneksi.php";
  $session_user = $_SESSION['user']; 
  $tampilpeserta = mysqli_query($mysqli, "SELECT Email, NISN, Nama, Nama_Jurusan, Jenis_Kelamin, Tanggal_Lahir, Alamat, Asal_Sekolah, Nilai_UN, Nilai_Akhir FROM peserta p join jurusan j on p.Id_Jurusan = j.Id_Jurusan where No_Pendaftaran = '$session_user'");
  $peserta = mysqli_fetch_assoc($tampilpeserta);
  if(isset($_SESSION['user']))
  {
    
?>

<!DOCTYPE html>
<html>
<head>
	<title>MAN 13 Jakarta - MAN 13 Jakarta</title>
	<link rel="icon" type="image/x-icon" href="../images/log.png" />
</head>
<style type="text/css">
	.rangkasurat {
		width: 980px;
		margin: 0 auto;
		background-color: #fff;
		height: 500px;
		padding: 20px;
	}
	.tengah {
		text-align: center;
		line-height: 5px;
	}

</style>
<body>
	<div class="rangkasurat">
		<table width="100%">
			<tr>
				<td><img src="../images/log.png" alt="" width="50" height="60"></td>
				<td class="tengah">
				<h2>Madrasah Aliyah Negri 13 Jakarta Selatan</h2>
				<h6>Jl. Syukur No.1, RT.1/RW.8, Lenteng Agung, Kec. Jagakarsa, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12610</h6>
				</td>
			</tr>
		</table>
		<hr>

	<center>
		<h3>Hasil Test Calon Peserta Didik Baru</h3>

		<table border="3">
			<tr>
				<td>No Pendaftaran</td>
				<td>:</td>
				<td><?php echo $session_user; ?></td>
			</tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td><?php echo $peserta['Email']; ?></td>
			</tr>
			<tr>
				<td>NISN</td>
				<td>:</td>
				<td><?php echo $peserta['NISN']; ?></td>
			</tr>
			<tr>
				<td>Jurusan</td>
				<td>:</td>
				<td><?php echo $peserta['Nama_Jurusan']; ?></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td>:</td>
				<td><?php echo $peserta['Nama']; ?></td>
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
				<td>:</td>
				<td>
					<?php
                        if ($peserta['Jenis_Kelamin'] == 'L') {
                            echo "Laki-Laki";
                        }
                        else{
                            echo "Perempuan";
                        }
                    ?>
				</td>
			</tr>
			<tr>
				<td>Tanggal Lahir</td>
				<td>:</td>
				<td>
					<?php 
                        $originalDate = $peserta['Tanggal_Lahir'];
                        $newDate = date("d-m-Y", strtotime($originalDate));
                        echo $newDate;
                    ?>
				</td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td>:</td>
				<td><?php echo $peserta['Alamat']; ?></td>
			</tr>
			<tr>
				<td>Asal Sekolah</td>
				<td>:</td>
				<td><?php echo $peserta['Asal_Sekolah']; ?></td>
			</tr>
			<tr>
				<td>Nilai Ujian Nasional</td>
				<td>:</td>
				<td><?php echo $peserta['Nilai_UN']; ?></td>
			</tr>
			<tr>
				<td>Selamat, Anda dinyatakan diterima di jurusan</td>
				<td></td>
				<td><?php echo $peserta['Nama_Jurusan']; ?></td>
			</tr>

		</table>
		</br>
		</br>
		</br>
		</br>
		</br>


		
		<table width="100%">
		<tr>
      			<td></td>
      			<td width="220px">
        		<p>Jakarta, Rabu
					<?php
						function tgl_indo($tanggal){
							$bulan = array (
								1 =>   'Januari',
								'Februari',
								'Maret',
								'April',
								'Mei',
								'Juni',
								'Juli',
								'Agustus',
								'September',
								'Oktober',
								'November',
								'Desember'
							);
							$pecahkan = explode('-', $tanggal);
							
							// variabel pecahkan 0 = tanggal
							// variabel pecahkan 1 = bulan
							// variabel pecahkan 2 = tahun
						 
							return $pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
						}

						echo tgl_indo(date('Y-m-d'));
					?>
				<br> Kepala Sekolah</p>
        		<br><br>
        		<p>__________________</p>
      			</td>
    	</tr>
		</table>
	</div>

	</center>
	

	<script>
		window.print();
		window.location='../user/' target="_blank";
	</script>
	
</body>
</html>

<?php 
	}
	else{
		header("location: ../login/");
	}
 ?>